#include <Wire.h>
#include <LiquidCrystal_I2C.h>
#include <HX711.h>
#include <Keypad.h>

// --- Pin Definitions ---
const int HX711_DOUT = 2;
const int HX711_CLK  = 3;
const int PUMP_PIN   = 7;
const int RED_LED    = 8;
const int GREEN_LED  = 9;

// --- Keypad Setup (4x4) ---
const byte ROWS = 4; 
const byte COLS = 4; 
char keys[ROWS][COLS] = {
  {'1','2','3','A'},
  {'4','5','6','B'},
  {'7','8','9','C'},
  {'*','0','#','D'}
};
// Connect to A3..A0 and 13..10
byte rowPins[ROWS] = {A3, A2, A1, A0}; 
byte colPins[COLS] = {13, 12, 11, 10}; 

Keypad keypad = Keypad(makeKeymap(keys), rowPins, colPins, ROWS, COLS);

// --- Object Initialization ---
LiquidCrystal_I2C lcd(0x27, 16, 4); // I2C address usually 0x27 or 0x3F
HX711 scale;

// --- Global Variables ---
float targetVolume = 100.0; // Default fill volume in ml
float density = 1.0;        // Default density (1.0 g/ml for water)
float calFactor = 420.0;    // Default scale calibration factor (needs calibration)

// System States
enum State { STATE_IDLE, WAIT_BOTTLE, FILLING, DONE };
State currentState = STATE_IDLE;

void setup() {
  Serial.begin(9600);
  
  pinMode(PUMP_PIN, OUTPUT);
  pinMode(RED_LED, OUTPUT);
  pinMode(GREEN_LED, OUTPUT);
  
  digitalWrite(PUMP_PIN, LOW);
  digitalWrite(RED_LED, HIGH);   // Red ON during standby
  digitalWrite(GREEN_LED, LOW);
  
  lcd.init();
  lcd.backlight();
  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("Bottle Filler");
  lcd.setCursor(0, 1);
  lcd.print("Initializing...");

  scale.begin(HX711_DOUT, HX711_CLK);
  scale.set_scale(calFactor);
  scale.tare(); // Zero the scale on startup

  delay(2000);
  updateMenuDisplay();
}

void loop() {
  char key = keypad.getKey();

  switch (currentState) {
    
    // ---------------------------------------------------------
    case STATE_IDLE:
      digitalWrite(RED_LED, HIGH);
      digitalWrite(GREEN_LED, LOW);
      
      if (key) {
        if (key == 'A') {
          targetVolume = readKeypadNumber("Target Vol (ml):");
          updateMenuDisplay();
        } 
        else if (key == 'B') {
          density = readKeypadNumber("Density (g/ml):");
          if(density <= 0) density = 1.0; // Prevent division by zero
          updateMenuDisplay();
        } 
        else if (key == 'C') {
          calibrateScale();
          updateMenuDisplay();
        } 
        else if (key == 'D') {
          currentState = WAIT_BOTTLE;
          lcd.clear();
          lcd.setCursor(0,0);
          lcd.print("Place bottle...");
          lcd.setCursor(0,1);
          lcd.print("Waiting for wt");
          lcd.setCursor(0,3);
          lcd.print("Cancel: Press *");
        }
      }
      break;

    // ---------------------------------------------------------
    case WAIT_BOTTLE:
      if (key == '*') { 
        currentState = STATE_IDLE; 
        updateMenuDisplay(); 
      }
      
      // Look for a sudden increase in weight (bottle placed)
      if (scale.get_units(3) > 10.0) { // Assuming bottle weighs at least 10g
        lcd.clear();
        lcd.print("Bottle Detected!");
        delay(1500); // Wait for the bottle to stop shaking
        
        scale.tare(); // Zero out the weight of the empty bottle!
        
        currentState = FILLING;
        digitalWrite(PUMP_PIN, HIGH); // Turn ON PUMP
      }
      break;

    // ---------------------------------------------------------
    case FILLING:
      digitalWrite(RED_LED, HIGH);   // Red ON indicates danger/working
      digitalWrite(GREEN_LED, LOW);
      
      if (key == '*') { // Emergency stop
        digitalWrite(PUMP_PIN, LOW);
        currentState = STATE_IDLE;
        updateMenuDisplay();
      } else {
        float mass = scale.get_units(1); // Get mass of liquid added
        if (mass < 0) mass = 0;
        
        // Calculate volume based on liquid density: Volume = Mass / Density
        float currentVolume = mass / density;
        
        lcd.setCursor(0, 0); lcd.print("FILLING...  STOP:*");
        lcd.setCursor(0, 1); lcd.print("Target: " + String(targetVolume, 1) + "ml  ");
        lcd.setCursor(0, 2); lcd.print("Vol:  " + String(currentVolume, 1) + "ml     ");
        lcd.setCursor(0, 3); lcd.print("Mass: " + String(mass, 1) + "g      ");

        // Check if target reached
        if (currentVolume >= targetVolume) {
          digitalWrite(PUMP_PIN, LOW); // Turn OFF PUMP
          currentState = DONE;
          
          digitalWrite(RED_LED, LOW);
          digitalWrite(GREEN_LED, HIGH); // Green ON indicates done
          
          lcd.clear();
          lcd.setCursor(0, 0); lcd.print("Fill Complete!");
          lcd.setCursor(0, 1); lcd.print("Vol: " + String(currentVolume, 1) + "ml");
          lcd.setCursor(0, 3); lcd.print("Remove bottle...");
        }
      }
      break;

    // ---------------------------------------------------------
    case DONE:
      // Wait for bottle to be removed (weight drops significantly below zero since we tared it)
      if (scale.get_units(3) < -10.0 || key == '*') { 
        digitalWrite(GREEN_LED, LOW);
        currentState = STATE_IDLE;
        scale.tare(); // Re-zero the scale 
        updateMenuDisplay();
      }
      break;
  }
}

// --- Helper Functions ---

void updateMenuDisplay() {
  lcd.clear();
  lcd.setCursor(0, 0); lcd.print("A:Vol  B:Density");
  lcd.setCursor(0, 1); lcd.print("C:Cal  D:Start");
  lcd.setCursor(0, 2); lcd.print("TV:" + String(targetVolume,0) + " D:" + String(density,2));
  lcd.setCursor(0, 3); lcd.print("Ready...");
}

float readKeypadNumber(String prompt) {
  String inputString = "";
  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print(prompt);
  lcd.setCursor(0, 1);
  
  while (true) {
    char k = keypad.getKey();
    if (k) {
      if (k >= '0' && k <= '9') {
        inputString += k;
        lcd.print(k);
      } else if (k == '*') { // Use '*' as decimal point
        inputString += '.';
        lcd.print('.');
      } else if (k == '#') { // Use '#' as Enter/Confirm
        return inputString.toFloat();
      } else if (k == 'D') { // Cancel
        return 0.0;
      }
    }
  }
}

void calibrateScale() {
  lcd.clear();
  lcd.setCursor(0,0); lcd.print("Clear the scale");
  lcd.setCursor(0,1); lcd.print("Press # to Tare");
  
  // Wait for #
  while (keypad.getKey() != '#');
  scale.set_scale(); // Reset scale to default
  scale.tare();      // Tare the empty scale
  
  lcd.clear();
  lcd.setCursor(0,0); lcd.print("Place known wght");
  lcd.setCursor(0,1); lcd.print("Then press #");
  
  // Wait for #
  while (keypad.getKey() != '#');
  
  // Get raw reading
  long rawValue = scale.get_units(10); 
  
  // Ask user for the known weight they placed
  float knownWeight = readKeypadNumber("Enter wght (g):");
  
  if (knownWeight > 0) {
    calFactor = (float)rawValue / knownWeight;
    scale.set_scale(calFactor);
    
    lcd.clear();
    lcd.setCursor(0,0); lcd.print("Calibrated!");
    lcd.setCursor(0,1); lcd.print("Factor:");
    lcd.setCursor(0,2); lcd.print(calFactor);
    delay(2000);
  }
}