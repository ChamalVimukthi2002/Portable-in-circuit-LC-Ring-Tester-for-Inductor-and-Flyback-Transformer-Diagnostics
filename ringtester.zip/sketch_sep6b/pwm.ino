
/**
 * Configure and start 8-bit Hardware PWM2 on Pin 31 (P3.1).
 * 
 * @param duty_cycle: 0 (0% duty / off) to 255 (100% duty / fully on).
 * Frequency: ~93.75 kHz at 24 MHz Fsys (24 MHz / 256).
 */
void pwm2_init(uint8_t duty_cycle) {
  // 1. Configure P3.1 as Push-Pull Output
  P3_MOD_OC &= ~(1 << 1);
  P3_DIR_PU |=  (1 << 1);

  // 2. Remap PWM2 output from P3.4 to P3.1 (bit 4 of PIN_FUNC)
  PIN_FUNC |= (1 << 4);

  // 3. Set initial duty cycle
  PWM_DATA2 = duty_cycle;

  // 4. Enable PWM2 output (bit 6 of PWM_CTRL)
  PWM_CTRL |= (1 << 6);
}

/**
 * Dynamically adjust PWM2 duty cycle.
 */
void pwm2_set_duty(uint8_t duty_cycle) {
  PWM_DATA2 = duty_cycle;
}

/**
 * Disable PWM2 output and drive pin low.
 */
void pwm2_stop(void) {
  PWM_CTRL &= ~(1 << 6);  // Disable PWM2 output
  P3_1 = 0;               // Drive low
}