
// Configure Timer 2 as 16-bit Counter clocked by Pin 10 (P1.0 / T2)
void initTimer2Counter(void) {
  pinMode(SENSE_PIN, INPUT);

  // Set C/T2 = 1 (Counter mode: increments on 1-to-0 transitions on T2/P1.0)
  // CP/RL2 = 0, TR2 = 0 (stopped initially)
  T2CON = 0x02; 
  T2MOD = 0x00; 

  RCAP2L = 0;
  RCAP2H = 0;
  TL2 = 0;
  TH2 = 0;
}

uint16_t runRingTest(void) {
  // Clear and start Timer 2 hardware counter
  TR2 = 0;
  TL2 = 0;
  TH2 = 0;
  TR2 = 1; // Timer 2 is now counting falling edges on P1.0

  // Fire excitation pulse on P3.3
  digitalWrite(PULSE_PIN, HIGH);


  // Wait 100ms for ringing oscillations to decay
  //delay(100);

  // Stop Timer 2 and read count
  TR2 = 0;
  delay(1000);
  digitalWrite(PULSE_PIN, LOW);
  return (((uint16_t)TH2 << 8) | TL2);
}
