void lightSegment(uint8_t anodeIdx, uint8_t cathodeIdx) {
  pinMode(PINS[anodeIdx], OUTPUT);
  digitalWrite(PINS[anodeIdx], HIGH);

  pinMode(PINS[cathodeIdx], OUTPUT);
  digitalWrite(PINS[cathodeIdx], LOW);

  delayMicroseconds(250);

  pinMode(PINS[anodeIdx], INPUT);
  pinMode(PINS[cathodeIdx], INPUT);
}

void displayNumber(uint8_t num, uint16_t duration_ms) {
  if (num > 99) num = 99;

  uint8_t digits[2];
  digits[0] = num / 10;
  digits[1] = num % 10;

  unsigned long start = millis();
  do {
    for (uint8_t d = 0; d < 2; d++) {
      uint8_t pattern = DIGIT_PATTERNS[digits[d]];
      for (uint8_t s = 0; s < 7; s++) {
        if (pattern & (1 << s)) {
          lightSegment(SEG_MAP[d][s][0], SEG_MAP[d][s][1]);
        }
      }
    }
  } while ((millis() - start) < duration_ms);
}

void displayDashes(uint16_t duration_ms) {
  unsigned long start = millis();
  do {
    for (uint8_t d = 0; d < 2; d++) {
      lightSegment(SEG_MAP[d][6][0], SEG_MAP[d][6][1]); // Segment G
    }
  } while ((millis() - start) < duration_ms);
}