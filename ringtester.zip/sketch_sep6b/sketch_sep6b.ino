#include <Arduino.h>
#include <stdint.h>

#define PULSE_PIN 30   // P3.3 (Pin 11 on CH552T) for excitation pulse
#define SENSE_PIN 33   // P1.0 (Pin 7 on CH552T / T2 pin) for hardware counting

const uint8_t PINS[6] = {11, 15, 16, 17, 14, 32}; 

const uint8_t SEG_MAP[2][7][2] = {
  // Digit 2 (Tens) -> Segments A-G {Anode, Cathode}
  { {3, 1}, {4, 1}, {5, 1}, {0, 2}, {1, 2}, {3, 2}, {4, 2} },
  // Digit 3 (Ones) -> Segments A-G {Anode, Cathode}
  { {5, 2}, {0, 3}, {1, 3}, {2, 3}, {4, 3}, {5, 3}, {5, 4} }
};

const uint8_t DIGIT_PATTERNS[10] = {
  0b00111111, // 0
  0b00000110, // 1
  0b01011011, // 2
  0b01001111, // 3
  0b01100110, // 4
  0b01101101, // 5
  0b01111101, // 6
  0b00000111, // 7
  0b01111111, // 8
  0b01101111  // 9
};

void initTimer2Counter(void);
uint16_t runRingTest(void);
void lightSegment(uint8_t anodeIdx, uint8_t cathodeIdx);
void displayNumber(uint8_t num, uint16_t duration_ms);
void displayDashes(uint16_t duration_ms);
void pwm2_init(uint8_t duty_cycle);
void pwm2_set_duty(uint8_t duty_cycle);

void setup() {
  for (uint8_t i = 0; i < 6; i++) {
    pinMode(PINS[i], INPUT);
  }

  pinMode(PULSE_PIN, OUTPUT);
  digitalWrite(PULSE_PIN, LOW);

  initTimer2Counter();

  pwm2_init(50);
  pwm2_set_duty(50);

  // Startup flash: "88" for 300ms
  displayNumber(88, 300);
}

void loop() {
  uint16_t raw_pulses = runRingTest();

  if (raw_pulses == 0) {
    // Show "--" when no pulses detected
    displayDashes(1000);
  } else {
    // Show pulse_count - 1
    uint16_t display_count = raw_pulses - 1;
    displayNumber((uint8_t)display_count, 1000);
  }
}