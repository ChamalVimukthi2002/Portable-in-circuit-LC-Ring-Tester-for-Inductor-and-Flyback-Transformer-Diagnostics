/*
 * CH552 Charlieplexed 3-Digit 7-Segment Display Tester
 * Pins: 13 (P1.3), 37 (P3.7), 36 (P3.6), 35 (P3.5), 34 (P3.4), 33 (P3.3)
 */

// Define the 6 pins connected to the display
const uint8_t PINS[6] = {36, 35, 34, 33, 31, 30};
const uint8_t NUM_PINS = 6;

// Puts unused pins in High-Impedance (INPUT) state,
// drives Anode HIGH, and Cathode LOW.
void driveSegment(int anodeIdx, int cathodeIdx) {
  for (int i = 0; i < NUM_PINS; i++) {
    if (i == anodeIdx) {
      pinMode(PINS[i], OUTPUT);
      digitalWrite(PINS[i], HIGH);
    } else if (i == cathodeIdx) {
      pinMode(PINS[i], OUTPUT);
      digitalWrite(PINS[i], LOW);
    } else {
      // Essential for Charlieplexing: Tri-state (High-Z)
      pinMode(PINS[i], INPUT);
    }
  }
}

// Turn off all segments
void allOff() {
  for (int i = 0; i < NUM_PINS; i++) {
    pinMode(PINS[i], INPUT);
  }
}

void setup() {
  allOff();
}

void loop() {
  // ======================================================
  // PHASE 1: SEQUENTIAL SCAN
  // Note down which segment/digit lights up for each pair!
  // ======================================================
  for (int a = 0; a < NUM_PINS; a++) {
    for (int c = 0; c < NUM_PINS; c++) {
      if (a != c) {
        driveSegment(a, c);
        delay(400); // Pause so you can identify the segment
      }
    }
  }

  allOff();
  delay(1000);

  // ======================================================
  // PHASE 2: ALL-ON PERSISTENCE OF VISION (POV) DEMO
  // Rapid scanning makes all segments look continuously lit
  // ======================================================
  unsigned long startTime = millis();
  while (millis() - startTime < 3000) { // Run for 3 seconds
    for (int a = 0; a < NUM_PINS; a++) {
      for (int c = 0; c < NUM_PINS; c++) {
        if (a != c) {
          driveSegment(a, c);
          delayMicroseconds(800); // Rapid multiplexing refresh
        }
      }
    }
  }

  allOff();
  delay(1000);
}