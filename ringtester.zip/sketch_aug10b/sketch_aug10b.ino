// Output pins mapping: Index 0 (Pin 2) is LSB, Index 5 (Pin 7) is MSB
const uint8_t PINS[6] = {2, 3, 4, 5, 6, 7};
const uint8_t NUM_PINS = sizeof(PINS) / sizeof(PINS[0]);

// Push button configuration
const uint8_t BUTTON_PIN = 8;

// Sequence state variables
uint8_t currentState = 0; // Binary count (0 to 63)
const uint8_t MAX_STATES = 64;

// Debounce variables
bool lastButtonState = HIGH;
unsigned long lastDebounceTime = 0;
const unsigned long DEBOUNCE_DELAY = 50; // Milliseconds

void applyOutputState(uint8_t value) {
  for (uint8_t i = 0; i < NUM_PINS; i++) {
    // Extract bit value for each pin: bit 0 -> Pin 2, bit 5 -> Pin 7
    bool bitVal = (value >> i) & 0x01;
    digitalWrite(PINS[i], bitVal ? HIGH : LOW);
  }
}

void printBinaryState(uint8_t value) {
  Serial.print("Val [");
  if (value < 10) Serial.print(" ");
  Serial.print(value);
  Serial.print("] -> Binary: ");

  // Print from MSB (Pin 7) down to LSB (Pin 2)
  for (int8_t i = NUM_PINS - 1; i >= 0; i--) {
    bool bitVal = (value >> i) & 0x01;
    Serial.print(bitVal);
  }
  Serial.println();
}

void setup() {
  Serial.begin(115200);

  // Initialize output pins
  for (uint8_t i = 0; i < NUM_PINS; i++) {
    pinMode(PINS[i], OUTPUT);
  }

  // Initialize button with internal pull-up
  pinMode(BUTTON_PIN, INPUT_PULLUP);

  // Set initial state (000000)
  applyOutputState(currentState);
  printBinaryState(currentState);
}

void loop() {
  bool reading = digitalRead(BUTTON_PIN);

  // Debounce check
  if (reading != lastButtonState) {
    lastDebounceTime = millis();
    lastButtonState = reading;
  }

  if ((millis() - lastDebounceTime) > DEBOUNCE_DELAY) {
    static bool buttonPressed = false;

    // Active LOW button press detection
    if (reading == LOW && !buttonPressed) {
      buttonPressed = true;

      // Advance binary sequence (0 to 63, then rolls over back to 0)
      currentState = (currentState + 1) % MAX_STATES;

      // Update hardware outputs & display in Serial Monitor
      applyOutputState(currentState);
      printBinaryState(currentState);
    } 
    else if (reading == HIGH) {
      buttonPressed = false;
    }
  }
}