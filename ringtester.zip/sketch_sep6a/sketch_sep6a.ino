#include <Arduino.h>

// CH552 Pin definitions: Update these pin numbers to match your hardware layout
const uint8_t PINS[6] = {11, 14, 15, 16, 17, 32}; 

// 3D Array for Charlieplexing Pin Pairs: [Digit][Segment][0=Anode, 1=Cathode]
const uint8_t SEG_MAP[2][7][2] = {
  // Digit 2 (Tens) -> Segments A-G {Anode, Cathode}
  { {3, 1}, {4, 1}, {5, 1}, {0, 2}, {1, 2}, {3, 2}, {4, 2} },
  // Digit 3 (Ones) -> Segments A-G {Anode, Cathode}
  { {5, 2}, {0, 3}, {1, 3}, {2, 3}, {4, 3}, {5, 3}, {5, 4} }
};

// Bitmasks for digits 0-9 (Bit 0 = Segment A ... Bit 6 = Segment G)
const uint8_t DIGIT_PATTERNS[10] = {
  0b00111111, // 0
  0b00000110, // 1
  0b01011011, // 2
  0b01001111, // 3
  0b01100110, // 4
  0b01101101, // 5
  0b01111101, // 6
  0b00000111, // 7
  0b01111111, // 8
  0b01101111  // 9
};

// Pulse a single segment on briefly
void lightSegment(uint8_t anodeIdx, uint8_t cathodeIdx) {
  pinMode(PINS[anodeIdx], OUTPUT);
  digitalWrite(PINS[anodeIdx], HIGH);

  pinMode(PINS[cathodeIdx], OUTPUT);
  digitalWrite(PINS[cathodeIdx], LOW);

  delayMicroseconds(250);

  // Return pins to High-Z (INPUT) mode
  pinMode(PINS[anodeIdx], INPUT);
  pinMode(PINS[cathodeIdx], INPUT);
}

/**
 * Core Display Function
 * Displays numbers from 0 to 99 for a specified duration in milliseconds.
 */
void displayNumber(uint8_t num, uint16_t duration_ms) {
  if (num > 99) num = 99;

  uint8_t digits[2];
  digits[0] = num / 10; // Tens digit
  digits[1] = num % 10; // Ones digit

  unsigned long start = millis();

  do {
    for (uint8_t d = 0; d < 2; d++) {
      uint8_t pattern = DIGIT_PATTERNS[digits[d]];
      for (uint8_t s = 0; s < 7; s++) {
        if (pattern & (1 << s)) {
          // Read Anode (index 0) and Cathode (index 1) directly from 3D array
          lightSegment(SEG_MAP[d][s][0], SEG_MAP[d][s][1]);
        }
      }
    }
  } while ((millis() - start) < duration_ms);
}

void setup() {
  // Set all 6 display pins to high-impedance INPUT state
  for (uint8_t i = 0; i < 6; i++) {
    pinMode(PINS[i], INPUT);
  }
}

void loop() {
  // Demo loop counting from 00 to 99
  for (uint8_t i = 0; i < 100; i++) {
    displayNumber(i, 200); 
  }
}