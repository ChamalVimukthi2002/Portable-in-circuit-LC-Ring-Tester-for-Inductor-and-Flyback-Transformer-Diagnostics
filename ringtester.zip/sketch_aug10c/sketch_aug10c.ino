// Arduino Pin Definitions
const uint8_t PINS[6] = {2, 3, 4, 5, 6, 7};

struct SegmentPin {
  uint8_t anode;
  uint8_t cathode;
};

// Segment mappings for Digit 2 (Tens) and Digit 3 (Ones) only
const SegmentPin SEG_MAP[2][7] = {
  // Digit 2 (Tens)
  { {3, 1}, {4, 1}, {5, 1}, {0, 2}, {1, 2}, {3, 2}, {4, 2} },
  // Digit 3 (Ones)
  { {5, 2}, {0, 3}, {1, 3}, {2, 3}, {4, 3}, {5, 3}, {5, 4} }
};

// 7-segment bitmasks for digits 0-9 (Bit 0 = A, Bit 1 = B, ..., Bit 6 = G)
const uint8_t DIGIT_PATTERNS[10] = {
  0b00111111, // 0
  0b00000110, // 1
  0b01011011, // 2
  0b01001111, // 3
  0b01100110, // 4
  0b01101101, // 5
  0b01111101, // 6
  0b00000111, // 7
  0b01111111, // 8
  0b01101111  // 9
};

int currentNumber = 0;
unsigned long lastIncrement = 0;
const unsigned long STEP_DELAY = 150; // Delay (ms) between numbers

void setup() {
  // Set all pins to High-Z INPUT state (keeps unused segments completely off)
  for (uint8_t i = 0; i < 6; i++) {
    pinMode(PINS[i], INPUT);
  }
}

// Multiplexes a single segment briefly
void lightSegment(uint8_t anodeIdx, uint8_t cathodeIdx) {
  pinMode(PINS[anodeIdx], OUTPUT);
  digitalWrite(PINS[anodeIdx], HIGH);

  pinMode(PINS[cathodeIdx], OUTPUT);
  digitalWrite(PINS[cathodeIdx], LOW);

  delayMicroseconds(300);

  // Return pins to High-Z mode immediately
  pinMode(PINS[anodeIdx], INPUT);
  pinMode(PINS[cathodeIdx], INPUT);
}

// Refreshes only Digits 2 and 3
void refreshDisplay(int num) {
  uint8_t digits[2];
  digits[0] = num / 10; // Tens -> Digit 2
  digits[1] = num % 10; // Ones -> Digit 3

  for (uint8_t d = 0; d < 2; d++) {
    uint8_t pattern = DIGIT_PATTERNS[digits[d]];
    for (uint8_t s = 0; s < 7; s++) {
      if (pattern & (1 << s)) {
        lightSegment(SEG_MAP[d][s].anode, SEG_MAP[d][s].cathode);
      }
    }
  }
}

void loop() {
  // Advance counter from 00 to 99
  if (millis() - lastIncrement >= STEP_DELAY) {
    lastIncrement = millis();
    currentNumber = (currentNumber + 1) % 100;
  }

  // Continuously drive the active display segments
  refreshDisplay(currentNumber);
}