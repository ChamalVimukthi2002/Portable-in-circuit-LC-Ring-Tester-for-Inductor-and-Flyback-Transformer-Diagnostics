const uint8_t PINS[6] = {2,3,4,5,6,7};
const uint8_t numPins = sizeof(PINS) / sizeof(PINS[0]);

String set = "111111.00";

/*
li = binary length
message = what is input

-- input format is "101101,01"
-- last bit is reverse if 1, bit before last bi is inverse if 1
-- limit applies to the left side bits of dot, another limit of two for extra function control bits.
-- input is checked to be valid.
-- 


*/
//function to handle binary serial inputs
String su (bool k = 1, byte li = 20, String va = "", String message = ""){
  //----------------------
    char myData[li + 5];
    char fd[li + 3];
    String fi ="";
    String x ="";
  //-----------------------
    bool ace = false; 
    bool p = true;
    bool error = false;
    bool s = false;
  //-----------------------
    byte y = 0;
    byte co = 0; // total length of the input
    byte le = 0; // filtered length of the left side
    byte ri = 0; // filtered length of right side
        // (co == le + ri + 1) --> true
  //-----------------------
    delay(400);

    while(!ace){
      if(!k){
        Serial.print(" set ");
        Serial.print(message);
        Serial.print("(currently:");
        Serial.print(va);
        Serial.print("): ");
      }
  le = 0;
  ri = 0;
  y = 0;
  co = 0; // total length of the input
  fi ="";
  x ="";
      while(p == true){
                error = false;
          while(Serial.available()==0){}
          delay(500);
          byte n = Serial.available();
          if(n!=0){
            byte m = Serial.readBytesUntil('\n', myData, 20);
            myData[m] = '\0';  //insert null charcater
            x = myData;
          }

          if(!k){
            co = x.length(); // get total length
            if(va.length() != 0 && co == 0){
            x = va;
            }
            Serial.print(x);
            Serial.print(" , ");
            co = x.length(); // get total length
            Serial.print(co);
            Serial.print(" , ");
          }
  //------------------------------- Process data ----------------------------------------------
  le = 0;
  ri = 0;
  y = 0;
  s = false; // very important, it needs to resetted or gonna cause problems with retry
  for(int i = 0; i < li+3 ; i++){
  char incomingChar = x.charAt(i);
      switch (incomingChar) {
        case '0':
                fd[y] = incomingChar;  // Append to our stored string
                y++;
                if(s == false){
                  le++;
                }else{
                  ri++;
                }
          break;
        case '1':
                fd[y] = incomingChar;  // Append to our stored string
                y++;
                if(s == false){
                  le++;
                }else{
                  ri++;
                }
          break;
        case '.':
                fd[y] = incomingChar;  // Append to our stored string
                  s = true;
                  y++;
          break;

      }
  }
            Serial.print(le);
            Serial.print(" , ");
            Serial.print(ri);
            Serial.print(" , ");
            fd[y] = '\0'; // insert a null character to remove the empty slot error [?]
            x = fd;
            if(!k){
            Serial.print(x);
            Serial.print(" , ");
            }

  // Validation --------
          if(!k){ // total length check
            if(co != li + ri + 1|| co > li+3){
              Serial.println("input unacceptable! ERRROR: over limit");
              Serial.print(" limit: ");
              Serial.print(li);
              Serial.println(" Enter input again!");
  le = 0;
  ri = 0;
  y = 0;
  co = 0; // total length of the input
  fi ="";
  x ="";
  s = false; // very important, it needs to resetted or gonna cause problems with retry
              break;
            }

  //----------------------
            le = le -1; // for loop runs using le and it needs to be le-1 
            s = false;// very important, it needs to resetted or gonna cause problems with retry
          
            //reverse
          if(fd[y-1] == '1'){
            for(int i = 0; i <= le; i++){
              fd[le - i] = x.charAt(i);
            }
          }
          //inverse
          if(fd[y-2]  == '1'){
            for(int i = le; i >= 0; i--){
              if(x.charAt(i) == '0'){
                fd[i] = '1';
              }else{
                fd[i] = '0';
              }
            }
          }
          // rebuilding output
          x = fd;
          fi = x.substring(0,le+1);

  //---------------------------------------------------------------------------------------------
            if(fi == va.substring(0,le+1)){
              Serial.print(message);
              Serial.println(" did not change!");
              le++;
              ace = true;
              p = false;
              break;
            }
            if(fi != va.substring(0,le+1)){
              Serial.print(message);
              Serial.println(" updated!");
              le++;
              ace = true;
              p = true;
              break;
            }
  //-----------------------------------------------------------------------------------------------
          }else{break;}
        }//----- End of the Serial-read while loop 

          //terminate for dummy function
          if(k){
            ace = true;
            p = false;
            break;
          }
    }//------- End  ace loop (retry loop)

    //----------------------------- empty function / dummy function ----------------> 
    /*
    empty function -> the Serial buffer bug or startup garbage issue that used to cause random characters 
    to show up when loop() first ran. That "phantom input" was such a pain. this is how you make it absorb it.
    Eg: byte w = su();
    */
    if(!k){
    return fi;
    }else{ // return for dummy function
      return "/0";
    }
    //----------------------------

  }


//-------------------------------------------------------------------------------------
void init_pins() {
  for (int i = 0; i < numPins; i++) {
    pinMode(PINS[i], OUTPUT);
  }
}

void setoutput() {
  for (int i = 5; i >= 0; i--) {
    int charIdx = abs(5 - i);
    if (set.charAt(abs(i-5)) == '0') {
      digitalWrite(PINS[i], LOW);
    } else {
      digitalWrite(PINS[i], HIGH);
    }
  }
  delay(200);
}


/*
 * setup() - this function runs once when you turn your Arduino on
 * We initialize the serial connection with the computer
 */
void setup() 
{
  Serial.begin(115200);
  init_pins();


}

/*
 * loop() - this function runs over and over again
 */
void loop() 
{
  set = su(0,6,set,"pins");
  Serial.println(set);
  setoutput();
}
